import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings as SettingsIcon, Database, Bot, ScanText, Building2 } from "lucide-react";

const features = [
  {
    icon: Database,
    title: "Database",
    description: "PostgreSQL with Drizzle ORM. All data is persisted with full CRUD operations.",
    status: "Active",
  },
  {
    icon: Bot,
    title: "AI Assistant",
    description: "Powered by Google Gemini 2.5 Flash via Replit AI Integrations. Streaming responses enabled.",
    status: "Active",
  },
  {
    icon: ScanText,
    title: "OCR Scanner",
    description: "Gemini Vision API for document text extraction and bill parsing.",
    status: "Active",
  },
  {
    icon: Building2,
    title: "Multi-Warehouse",
    description: "Track inventory across multiple warehouse locations with expiry tracking.",
    status: "Active",
  },
];

export default function Settings() {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground mt-1">Platform configuration and system information.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="h-5 w-5" /> Platform Information
          </CardTitle>
          <CardDescription>SIHIYAN — SIHI Seeds AI Operations Platform</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {[
              { label: "Platform", value: "SIHIYAN" },
              { label: "Version", value: "1.0.0" },
              { label: "Organization", value: "SIHI Seeds" },
              { label: "Environment", value: import.meta.env.MODE ?? "development" },
              { label: "API Base", value: "/api" },
              { label: "AI Model", value: "Gemini 2.5 Flash" },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between items-center py-2 border-b border-border/50">
                <span className="text-sm text-muted-foreground">{label}</span>
                <span className="text-sm font-medium font-mono">{value}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {features.map(({ icon: Icon, title, description, status }) => (
          <Card key={title}>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  {title}
                </div>
                <Badge variant="outline" className="text-emerald-600 border-emerald-600 text-xs">
                  {status}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tech Stack</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {[
              "React 19", "TypeScript", "Vite", "Tailwind CSS", "shadcn/ui",
              "Express 5", "Drizzle ORM", "PostgreSQL", "Google Gemini API",
              "TanStack Query", "Zod", "OpenAPI", "pnpm Workspaces"
            ].map((tech) => (
              <Badge key={tech} variant="secondary">{tech}</Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
