import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, dailyReportsTable, stockItemsTable, dispatchesTable } from "@workspace/db";
import { GetDailyReportParams } from "@workspace/api-zod";
import { ai } from "@workspace/integrations-gemini-ai";
import { logger } from "../../lib/logger";
import { sendSlackMessage, formatReportForSlack } from "../../lib/slack";

const router: IRouter = Router();

router.get("/reports/daily", async (_req, res): Promise<void> => {
  const reports = await db.select().from(dailyReportsTable).orderBy(dailyReportsTable.reportDate);
  res.json(reports);
});

router.post("/reports/daily", async (_req, res): Promise<void> => {
  const [stocks, dispatches] = await Promise.all([
    db.select().from(stockItemsTable),
    db.select().from(dispatchesTable),
  ]);

  const lowStock = stocks.filter(
    (s) => parseFloat(String(s.quantity)) <= parseFloat(String(s.minQuantity))
  );
  const totalValue = stocks.reduce(
    (s, i) => s + (parseFloat(String(i.quantity)) || 0) * (parseFloat(String(i.unitPrice ?? "0")) || 0),
    0
  );

  const prompt = `You are an AI assistant for SIHI Seeds. Generate a daily operations report as valid JSON with these exact keys: summary, stockInsights, dispatchInsights, recommendations.

Data:
- Stock items: ${stocks.length}, Low stock: ${lowStock.length} (${lowStock.map((s) => s.name).join(", ") || "none"})
- Total stock value: ₹${totalValue.toFixed(2)}
- Dispatches: total=${dispatches.length}, pending=${dispatches.filter((d) => d.status === "pending").length}, in_transit=${dispatches.filter((d) => d.status === "in_transit").length}, delivered=${dispatches.filter((d) => d.status === "delivered").length}

Respond ONLY with valid JSON, no markdown, no extra text.`;

  let summary = `Daily operations report - ${new Date().toLocaleDateString()}.`;
  let stockInsights: string | null = null;
  let dispatchInsights: string | null = null;
  let recommendations: string | null = null;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: { maxOutputTokens: 8192, responseMimeType: "application/json" },
    });

    const parsed = JSON.parse(response.text ?? "{}");
    summary = String(parsed.summary ?? summary);
    stockInsights = parsed.stockInsights ? String(parsed.stockInsights) : null;
    dispatchInsights = parsed.dispatchInsights ? String(parsed.dispatchInsights) : null;
    recommendations = parsed.recommendations ? String(parsed.recommendations) : null;
  } catch (err) {
    logger.warn({ err }, "Gemini report generation failed, using fallback");
  }

  const [report] = await db
    .insert(dailyReportsTable)
    .values({ reportDate: new Date(), summary, stockInsights, dispatchInsights, recommendations, generatedBy: "gemini-2.5-flash" })
    .returning();

  // Auto-post to Slack
  sendSlackMessage(formatReportForSlack(report)).catch((err) =>
    logger.warn({ err }, "Slack notification failed")
  );

  res.status(201).json(report);
});

router.get("/reports/daily/:id", async (req, res): Promise<void> => {
  const params = GetDailyReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [report] = await db
    .select()
    .from(dailyReportsTable)
    .where(eq(dailyReportsTable.id, params.data.id));

  if (!report) {
    res.status(404).json({ error: "Report not found" });
    return;
  }

  res.json(report);
});

router.post("/reports/daily/:id/send-slack", async (req, res): Promise<void> => {
  const params = GetDailyReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [report] = await db
    .select()
    .from(dailyReportsTable)
    .where(eq(dailyReportsTable.id, params.data.id));

  if (!report) {
    res.status(404).json({ error: "Report not found" });
    return;
  }

  await sendSlackMessage(formatReportForSlack(report));
  res.json({ ok: true });
});

export default router;
